package com.example.shine.testdata.tabsframework;

interface BackButtonAction {
  public void back();
}
