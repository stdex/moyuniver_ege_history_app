package com.example.shine.testdata.api;

import android.app.Activity;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Context;

import android.graphics.Point;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;


public class CONSTANTS {
    private CONSTANTS() {}

    public final static String APPID = "25";
    public final static String APPSGN = "8dffb3255579e96a66621160d1f193ac";
    public final static String OS = "android";
    public final static String VER = Build.VERSION.RELEASE;
    public final static String DID = "21";
}
